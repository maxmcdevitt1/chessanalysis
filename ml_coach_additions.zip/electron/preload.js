// inprogress/electron/preload.js
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('engine', {
  analyzeFen: (fen, opts = {}) => ipcRenderer.invoke('engine:analyzeFen', { fen, ...opts }),
  reviewPgn: (pgn, opts = {}) => ipcRenderer.invoke('engine:reviewPgn', { pgn, ...opts }),
  getCapabilities: () => ipcRenderer.invoke('engine:getCapabilities'),
  setStrength: ({ elo }) => ipcRenderer.invoke('engine:setStrength', { elo }),
  moveWeak: (payload) => {
    const p = (typeof payload === 'string') ? { fen: payload } : (payload || {});
    const { fen, movetimeMs = 300, multiPv = 1 } = p;
    return ipcRenderer.invoke('engine:moveWeak', { fen, movetimeMs, multiPv });
  },
  ping: () => ipcRenderer.invoke('engine:ping'),
});



contextBridge.exposeInMainWorld('coach', {
  generate: (inputs) => ipcRenderer.invoke('coach:generate', { inputs })
});
