// inprogress/electron/coachBridge.js
const http = require('http');
const https = require('https');
const { ipcMain } = require('electron');

const DEFAULT_MODEL = process.env.COACH_MODEL || 'qwen3:4b-instruct';
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';
const TIMEOUT_MS = Number(process.env.COACH_TIMEOUT_MS || 5000);

function doFetch(url, opts={}, signal){
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, { method: opts.method || 'GET', headers: opts.headers || {} }, res => {
      const chunks = [];
      res.on('data', d => chunks.push(d));
      res.on('end', () => resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    if (signal) {
      signal.addEventListener('abort', () => { try { req.destroy(new Error('aborted')); } catch {} });
    }
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

function registerCoachIpc(){
  ipcMain.handle('coach:generate', async (_e, payload) => {
    const inputs = (payload && payload.inputs) || {};
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const body = {
        model: DEFAULT_MODEL,
        stream: false,
        system: 'You are a concise chess coach. Produce brief notes (<=140 chars). Explain big eval swings and missed tactics. No markdown, no preambles.',
        prompt: buildPrompt(inputs),
        format: 'json',
        options: { temperature: 0.2, num_ctx: 2048 }
      };
      const res = await doFetch(`${OLLAMA_URL}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }, controller.signal);
      clearTimeout(t);
      if (!res.ok) throw new Error('ollama status ' + res.status);
      const parsed = JSON.parse(res.text);
      const raw = String(parsed?.response || '').trim();
      const notes = sanitizeNotes(tryParseArray(raw));
      if (!notes) throw new Error('bad json');
      return { notes };
    } catch (e) {
      clearTimeout(t);
      return { offline: true };
    }
  });
}

function buildPrompt(inputs){
  const summary = inputs.summary || {};
  const moments = Array.isArray(inputs.moments) ? inputs.moments : [];
  const pgn = inputs.pgn;
  const head = `Opening: ${summary.opening ?? 'Unknown'}; WhiteAcc: ${fmt(summary.whiteAcc)}%; BlackAcc: ${fmt(summary.blackAcc)}%; AvgCPL(W/B): ${fmt(summary.avgCplW)} / ${fmt(summary.avgCplB)}.`;
  const lines = moments.map(m => {
    const delta = (m.cpAfter!=null && m.cpBefore!=null) ? (m.cpAfter - m.cpBefore) : 'n/a';
    return `#${m.moveNo}${m.side?.[0]||'?'} ${m.san} [${m.tag}] Δcp=${delta}; best=${m.best ?? '-'}; idx=${m.index}`;
  });
  return [
    head,
    'Return ONLY JSON array of objects: {"type":"intro"|"move"|"summary","text":string,"moveIndex"?:number}.',
    'Each text <= 140 chars. Include moveIndex=idx when commenting a move. Prefer Mistake/Blunder and turning points.',
    'Moments:',
    ...lines,
    pgn ? ('\nPGN (truncated)\n' + String(pgn).slice(0,5000)) : ''
  ].join('\n');
}

function tryParseArray(s){
  try { const v = JSON.parse(s); return Array.isArray(v) ? v : null; } catch { return null; }
}
function sanitizeNotes(arr){
  if (!arr || !Array.isArray(arr) || arr.length < 1 || arr.length > 24) return null;
  const out = [];
  for (const o of arr){
    if (!o || typeof o !== 'object') return null;
    const type = o.type;
    const text = o.text;
    if (typeof text !== 'string' || text.length < 1 || text.length > 140) return null;
    if (type === 'intro' || type === 'summary'){
      out.push({ type, text });
    } else if (type === 'move') {
      const idx = o.moveIndex;
      if (!Number.isInteger(idx) || idx < 0) return null;
      out.push({ type, moveIndex: idx, text });
    } else {
      return null;
    }
  }
  return out;
}
function fmt(n){ return (typeof n === 'number' && isFinite(n)) ? Math.round(n) : '-'; }

module.exports = { registerCoachIpc };
