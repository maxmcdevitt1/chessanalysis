import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// webui/src/CoachPanel.tsx
import { useEffect, useRef } from 'react';
export default function CoachPanel({ coach, coachBusy, coachErr, notes = [], }) {
    const activeRef = useRef(null);
    useEffect(() => {
        activeRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, [notes]);
    if (coachBusy) {
        return _jsx("div", { style: { border: '1px solid #333', borderRadius: 6, padding: 12 }, children: "Coach: generating\u2026" });
    }
    if (coachErr) {
        return _jsxs("div", { style: { border: '1px solid #333', borderRadius: 6, padding: 12, color: '#ff8585' }, children: ["Coach error: ", coachErr] });
    }
    if (!coach)
        return null;
    return (_jsxs("div", { style: { border: '1px solid #333', borderRadius: 6, padding: 12 }, children: [_jsx("div", { style: { fontWeight: 700, marginBottom: 8 }, children: "Coach Notes" }), _jsx("div", { style: { opacity: 0.95, marginBottom: 8 }, children: coach.intro }), _jsx("div", { style: { maxHeight: 180, overflow: 'auto', border: '1px solid #333', borderRadius: 6, padding: 8 }, children: coach.perMove.map((c, i) => (_jsxs("div", { style: { marginBottom: 6 }, children: [_jsxs("strong", { style: { opacity: 0.8 }, children: ["ply ", c.ply + 1, ":"] }), " ", c.text] }, i))) }), _jsx("div", { style: { marginTop: 8, opacity: 0.95 }, children: coach.closing }), _jsx("div", { style: { marginTop: 12, maxHeight: 160, overflow: 'auto', borderTop: '1px solid #333', paddingTop: 8 }, children: notes.length ? notes.map((n, i) => {
                    const isActive = i === 0;
                    return (_jsx("div", { ref: isActive ? activeRef : null, style: {
                            marginBottom: 6,
                            padding: '6px 8px',
                            borderRadius: 6,
                            background: isActive ? '#2a2a2a' : 'transparent',
                            border: isActive ? '1px solid #555' : '1px solid transparent',
                            color: '#ddd',
                            fontSize: 14,
                            lineHeight: '18px',
                        }, title: n.type === 'move' && typeof n.moveIndex === 'number' ? `Move #${n.moveIndex + 1}` : n.type, children: n.text }, `${n.type}-${n.moveIndex ?? i}-${n.text.slice(0, 20)}`));
                }) : (_jsx("div", { style: { opacity: 0.6, fontSize: 13 }, children: "No note for this move." })) })] }));
}
