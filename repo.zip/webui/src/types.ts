export type Tag =
  | 'Book'
  | 'Best'
  | 'Good'
  | 'Inaccuracy'
  | 'Mistake'
  | 'Blunder'
  | 'Brilliant'
  | 'Genius'
  | 'Review';
