export type Color = 'w' | 'b';
export type Fen = string;
export type UciMove = string;

export type SideLabel = 'White' | 'Black';
