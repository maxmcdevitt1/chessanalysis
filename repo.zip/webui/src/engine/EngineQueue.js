export function createEngineQueue(analyze) {
    let ticket = 0; // increments to cancel stale calls
    let busy = false;
    async function run(params) {
        const my = ++ticket;
        busy = true;
        try {
            const res = await analyze(params);
            if (my !== ticket)
                throw new Error('stale'); // ignore stale results
            return res;
        }
        finally {
            if (my === ticket)
                busy = false;
        }
    }
    return {
        get busy() { return busy; },
        evalQuick: (p) => run(p),
        analyzeHeavy: (p) => run(p),
        cancelAll: () => { ticket++; busy = false; },
        /** Batch fast review – returns [{ idx, bestMove, score }] */
        async reviewFast(fens, elo, opts) {
            // @ts-ignore preload exposes window.electron.engine.reviewFast
            const res = await window?.electron?.engine?.reviewFast?.(fens, elo, opts);
            const arr = Array.isArray(res) ? res.slice().sort((a, b) => a.idx - b.idx) : [];
            return arr.map((r) => ({
                idx: r?.idx | 0,
                bestMove: r?.bestMove ?? null,
                score: r?.score ?? null,
            }));
        },
    };
}
