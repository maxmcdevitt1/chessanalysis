// webui/src/CommentaryService.ts
// Generic interface for commentary providers.
export {};
