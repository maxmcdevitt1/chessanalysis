import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// webui/src/BoardPane.tsx — big board, tall eval bar to the right, large controls; badge top-right inside square
import { useMemo, useRef, useState, useEffect } from 'react';
import { Chessboard } from 'react-chessboard';
import EvalSparkline from './EvalSparkline';
import { TagBadge } from './TagBadges';
/* --------------------------------- UI Kit -------------------------------- */
const ui = {
    row: { display: 'flex', gap: 14, flexWrap: 'wrap', justifyContent: 'center' },
    col: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 },
    btn: {
        padding: '11px 14px',
        fontSize: 15,
        lineHeight: '19px',
        borderRadius: 12,
        border: '1px solid #1f2a3a',
        background: 'linear-gradient(180deg, #1f2b3d, #0f172a)',
        color: '#e9f1ff',
        boxShadow: '0 10px 26px rgba(0,0,0,.35)',
        cursor: 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        fontWeight: 600,
        letterSpacing: '0.2px',
    },
    btnIcon: {
        padding: '10px',
        width: 46,
        height: 46,
        minWidth: 46,
        borderRadius: 12,
        border: '1px solid #1f2a3a',
        background: 'linear-gradient(180deg, #1f2b3d, #0f172a)',
        color: '#e9f1ff',
        boxShadow: '0 10px 26px rgba(0,0,0,.35)',
        cursor: 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    select: {
        padding: '8px 10px',
        borderRadius: 10,
        background: '#0b1220',
        color: '#e9f1ff',
        border: '1px solid #203046',
        fontSize: 14,
    },
    pill: {
        padding: '8px 10px',
        borderRadius: 10,
        background: '#0b1220',
        border: '1px solid #203046',
        color: '#d7e5ff',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 14,
        boxShadow: '0 6px 16px rgba(0,0,0,0.3)',
    },
    controlGrid: {
        width: '100%',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
        gap: 10,
        alignItems: 'stretch',
    },
    status: { fontSize: 12, color: '#9ca3af' },
    toggle: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '11px 14px',
        borderRadius: 12,
        border: '1px solid #1f2a3a',
        background: '#0c1526',
        color: '#d7e5ff',
        cursor: 'pointer',
        boxShadow: '0 10px 26px rgba(0,0,0,.35)',
        userSelect: 'none',
    },
};
/* ----------------------------- Small helpers ----------------------------- */
function fileIdx(f) {
    return 'abcdefgh'.indexOf(f) + 1;
}
function Icon({ name, size = 18 }) {
    const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'currentColor' };
    switch (name) {
        case 'play':
        case 'begin':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M7 5l12 7-12 7V5z" }) });
        case 'clock':
            return _jsxs("svg", { ...common, children: [_jsx("circle", { cx: "12", cy: "12", r: "9", stroke: "currentColor", strokeWidth: "2", fill: "none" }), _jsx("path", { d: "M12 7v6l4 2", stroke: "currentColor", strokeWidth: "2", fill: "none", strokeLinecap: "round" })] });
        case 'rewind':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M7 12l9-6v12l-9-6z" }), _jsx("path", { d: "M6 6v12", stroke: "currentColor", strokeWidth: "2" })] });
        case 'back':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M16 6l-9 6 9 6V6z" }) });
        case 'forward':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M8 6l9 6-9 6V6z" }) });
        case 'end':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M18 6v12", stroke: "currentColor", strokeWidth: "2" }), _jsx("path", { d: "M8 6l9 6-9 6V6z" })] });
        case 'plus':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M12 5v14M5 12h14", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }) });
        case 'cpu':
            return _jsxs("svg", { ...common, children: [_jsx("rect", { x: "7", y: "7", width: "10", height: "10", rx: "2" }), _jsx("path", { d: "M4 10h3M4 14h3M17 10h3M17 14h3M10 4v3M14 4v3M10 17v3M14 17v3", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" })] });
        case 'handshake':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M7 13l2.5 2.5a2 2 0 002.8 0l2.2-2.2L17 14l2-2-2-2-2 1-2-2-3 3", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" }) });
        case 'flag':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M6 4v16M8 4h8l-2 3 2 3H8", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" }) });
        case 'repeat':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M4 11V7a1 1 0 011-1h10l-2-2 2 2-2 2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" }), _jsx("path", { d: "M20 13v4a1 1 0 01-1 1H9l2 2-2-2 2-2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" })] });
        case 'knight':
            return _jsx("svg", { ...common, children: _jsx("path", { d: "M16 5l-6 3-2 4 2 2v3H7v2h10v-2h-3v-5l3-3-1-4z" }) });
        case 'flip':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M7 10h8l-2-2 2 2-2 2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" }), _jsx("path", { d: "M17 14H9l2 2-2-2 2-2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", fill: "none" })] });
        case 'kingW':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M12 5v4M10 7h4", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }), _jsx("path", { d: "M8 11h8l-1 6H9l-1-6z" })] });
        case 'kingB':
            return _jsxs("svg", { ...common, children: [_jsx("path", { d: "M12 6v3M11 7h2", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }), _jsx("path", { d: "M8 10h8l-1 6H9l-1-6z", fill: "currentColor" })] });
        default:
            return null;
    }
}
function PlayerBadge({ side, name, acc, estElo, }) {
    const isWhite = side === 'white';
    const bg = isWhite ? '#f5f5f5' : '#2f2f33';
    const fg = isWhite ? '#222' : '#f3f4f6';
    const border = isWhite ? '#e0e0e0' : '#3f3f45';
    const pillBg = isWhite ? '#e8e8e8' : '#3a3a40';
    return (_jsxs("div", { style: {
            minWidth: 160,
            padding: '10px 12px',
            borderRadius: 12,
            background: bg,
            color: fg,
            border: `1px solid ${border}`,
            boxShadow: '0 2px 6px rgba(0,0,0,0.25)',
            display: 'flex',
            flexDirection: 'column',
            gap: 6,
            alignItems: 'flex-start',
        }, children: [_jsx("div", { style: { fontSize: 16, fontWeight: 700 }, children: name }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: [_jsxs("span", { style: { padding: '4px 8px', borderRadius: 8, background: pillBg, color: fg, fontWeight: 600 }, title: "Estimated playing strength from the game review", children: ["Est. Elo: ", estElo != null ? Math.round(estElo) : '—'] }), _jsxs("span", { style: { padding: '4px 8px', borderRadius: 8, background: pillBg, color: fg, fontWeight: 600 }, children: ["Acc: ", acc != null ? `${Math.round(acc)}%` : '—'] })] })] }));
}
function RenderBadge({ tag, size = 24 }) {
    return _jsx(TagBadge, { tag: tag ?? null, size: size });
}
/**
 * Fit the board to available space (container width minus eval column),
 * while also respecting the window height so it never shrinks too far.
 */
function useStableBoardWidth(minPx = 900, maxPx = 1340, initial = 1040) {
    const ref = useRef(null);
    const [w, setW] = useState(initial);
    useEffect(() => {
        if (!ref.current)
            return;
        let raf = 0;
        const EVAL_RIGHT_COL = 160; // eval bar + label + gutter
        const GUTTER = 28;
        const ro = new ResizeObserver(([entry]) => {
            if (!entry)
                return;
            cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
                const availW = Math.floor(entry.contentRect.width - (EVAL_RIGHT_COL + GUTTER));
                const availH = Math.floor(window.innerHeight - 140); // leave more vertical room for a taller board
                const target = Math.max(minPx, Math.min(maxPx, Math.min(availW, availH)));
                const even = Math.floor(target / 2) * 2; // crisp squares
                setW(prev => (Math.abs(prev - even) >= 2 ? even : prev));
            });
        });
        ro.observe(ref.current);
        return () => { cancelAnimationFrame(raf); ro.disconnect(); };
    }, [minPx, maxPx]);
    return { containerRef: ref, boardWidth: w };
}
/** last numeric in an array (used for eval fallback) */
function lastNumber(a) {
    if (!a || !a.length)
        return null;
    for (let i = a.length - 1; i >= 0; i--) {
        const v = a[i];
        if (typeof v === 'number' && isFinite(v))
            return v;
    }
    return null;
}
/* ------------------------------ Eval bar --------------------------------- */
/** Shows a number consistently: if pending and cp available, append " …" instead of hiding it. */
function EvalBar({ cp, pending, height }) {
    const capped = cp == null ? 0 : Math.max(-1000, Math.min(1000, cp));
    const whitePct = Math.max(0, Math.min(100, 50 + capped / 20));
    const blackPct = 100 - whitePct;
    const barHeight = Math.max(260, Math.floor(height)); // tall, but never tiny
    const num = cp == null ? null : (cp / 100).toFixed(1);
    const label = num != null ? `${cp >= 0 ? '+' : ''}${num}${pending ? ' …' : ''}` : (pending ? '…' : '—');
    return (_jsxs("div", { style: { display: 'flex', gap: 14, alignItems: 'center' }, children: [_jsxs("div", { style: {
                    width: 34,
                    height: barHeight,
                    border: '2px solid #444',
                    borderRadius: 6,
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    background: '#000',
                }, children: [_jsx("div", { style: { flexBasis: `${whitePct}%`, background: '#fff' } }), _jsx("div", { style: { flexBasis: `${blackPct}%`, background: '#000' } })] }), _jsxs("div", { style: { fontSize: 16, color: '#ddd', minWidth: 56 }, children: [label, _jsx("div", { style: { opacity: .6, fontSize: 14 }, children: "Eval" })] })] }));
}
/* ---------------------------------- View ---------------------------------- */
export default function BoardPane(props) {
    const { fen, orientation, evalCp, evalPending, movesUci, ply, onUserDrop, onRebuildTo, onEngineMove, onOfferDraw, onBeginMatch, onResign, onNewGame, autoReply, setAutoReply, engineBusy, bestArrow, gameOver, timeControlMinutes, onTimeControlChange, clockMs, clockRunning, matchStarted, currentMoveEval, evalSeries, showEvalGraph, onOrientationChange, hasAnalysis, } = props;
    const { customSquareStyles, bookMask, currentPly, lastMove } = props;
    const { whiteName = 'White', blackName = 'Black', whiteAcc = null, blackAcc = null, whiteEstElo = null, blackEstElo = null, engineTargetElo = null, engineTargetLabel = null, engineTargetRange = null, } = props;
    const { containerRef, boardWidth } = useStableBoardWidth();
    const [selectedSquare, setSelectedSquare] = useState(null);
    // Clear any pending click-selection when position changes (e.g., after a move).
    useEffect(() => { setSelectedSquare(null); }, [fen]);
    // Eval number to display: prefer live cp; else fallback to last known
    const evalCpDisplay = useMemo(() => {
        if (typeof evalCp === 'number' && isFinite(evalCp))
            return evalCp;
        return lastNumber(evalSeries);
    }, [evalCp, evalSeries]);
    const isGameOver = !!gameOver;
    const btnStyle = (disabled) => ({
        ...ui.btn,
        opacity: disabled ? 0.55 : 1,
        cursor: disabled ? 'not-allowed' : 'pointer',
    });
    const outcomeText = useMemo(() => {
        if (!gameOver)
            return null;
        const { reason, winner } = gameOver;
        if (reason === 'checkmate')
            return `${winner || 'Winner'} wins by checkmate`;
        if (reason === 'stalemate')
            return 'Draw by stalemate';
        if (reason === 'threefold')
            return 'Draw by threefold repetition';
        if (reason === 'fifty-move')
            return 'Draw by fifty-move rule';
        if (reason === 'insufficient')
            return 'Draw by insufficient material';
        if (reason === 'agreement')
            return 'Draw by agreement';
        if (reason === 'resign')
            return `${winner || 'Opponent'} wins by resignation`;
        if (reason === 'flag')
            return `${winner || 'Opponent'} wins on time`;
        return 'Draw';
    }, [gameOver]);
    const clockLabel = (ms) => {
        if (ms == null || !isFinite(ms))
            return '--:--';
        const total = Math.max(0, Math.floor(ms / 1000));
        const m = Math.floor(total / 60);
        const s = total % 60;
        return `${m}:${String(s).padStart(2, '0')}`;
    };
    /* ---------- Badge: size + position (top-right inside destination square) ---------- */
    const squareSize = Math.floor(boardWidth / 8);
    const badgeSize = Math.min(54, Math.max(22, Math.floor(squareSize * 0.60))); // ~60% of a square
    const offset = Math.max(2, Math.floor(squareSize * 0.04)); // hug top-right
    const destUci = currentMoveEval?.uci ?? (ply > 0 ? movesUci[ply - 1] : undefined);
    const destSquare = destUci ? destUci.slice(2, 4) : undefined;
    // Board overlays only after analysis; no book/other icons before that.
    const isBookMove = hasAnalysis && Array.isArray(bookMask) && typeof currentPly === 'number' && currentPly > 0 && !!bookMask[currentPly - 1];
    const overlayTag = hasAnalysis
        ? (isBookMove ? 'Book' : (currentMoveEval?.tag ?? null))
        : null;
    const badgeAnalysisReady = !!(hasAnalysis && Array.isArray(evalSeries) && evalSeries.length >= ply);
    const showBadge = !!(badgeAnalysisReady && overlayTag && destSquare && ply > 0);
    const badgePos = useMemo(() => {
        if (!showBadge || !destSquare || destSquare.length !== 2)
            return null;
        const file = destSquare[0].toLowerCase();
        const rank = Number(destSquare[1]);
        if (!'abcdefgh'.includes(file) || !Number.isFinite(rank))
            return null;
        const col0 = fileIdx(file) - 1; // 0..7 from white's left
        const row0 = rank - 1; // 0..7 from white's bottom
        const col = orientation === 'white' ? col0 : 7 - col0;
        const row = orientation === 'white' ? 7 - row0 : row0;
        const left = col * squareSize + Math.max(0, squareSize - badgeSize - offset);
        const top = row * squareSize + offset;
        return { left, top };
    }, [showBadge, destSquare, orientation, squareSize, badgeSize, offset]);
    /* ------------------------------ Arrows & Drops ------------------------------ */
    const arrows = useMemo(() => (bestArrow ? [[bestArrow.from, bestArrow.to]] : []), [bestArrow?.from, bestArrow?.to]);
    // Add a book badge to from/to squares if the current ply is still in book.
    const mergedSquareStyles = useMemo(() => {
        const base = customSquareStyles ? { ...customSquareStyles } : {};
        const tag = hasAnalysis ? currentMoveEval?.tag : null;
        const square = destSquare?.toLowerCase?.();
        if (square && (tag === 'Best' || tag === 'Blunder')) {
            const color = tag === 'Best' ? 'rgba(46,204,113,0.55)' : 'rgba(231,76,60,0.55)';
            base[square] = {
                ...(base[square] || {}),
                boxShadow: `inset 0 0 0 4px ${color}`,
                background: `radial-gradient(circle at center, ${color} 0%, ${color} 40%, transparent 75%)`,
            };
        }
        if (selectedSquare) {
            const key = selectedSquare.toLowerCase();
            base[key] = {
                ...(base[key] || {}),
                boxShadow: 'inset 0 0 0 3px rgba(88,166,255,0.8)',
                background: 'radial-gradient(circle at center, rgba(88,166,255,0.25) 0%, rgba(88,166,255,0.18) 45%, transparent 70%)',
            };
        }
        return base;
    }, [customSquareStyles, hasAnalysis, currentMoveEval?.tag, destSquare, selectedSquare]);
    function onPieceDrop(from, to) {
        const ok = onUserDrop(from, to);
        if (ok)
            setSelectedSquare(null);
        return ok;
    }
    // Allow click-to-move: first click selects a source, second click attempts the move.
    function handleSquareClick(square) {
        if (selectedSquare === square) {
            setSelectedSquare(null);
            return;
        }
        if (selectedSquare) {
            const ok = onUserDrop(selectedSquare, square);
            if (ok) {
                setSelectedSquare(null);
            }
            else {
                setSelectedSquare(square);
            }
            return;
        }
        setSelectedSquare(square);
    }
    /* ------------------------------ Layout numbers ------------------------------ */
    // Eval bar matches board height
    const evalBarHeight = boardWidth;
    // Make the eval graph taller but keep width aligned to the board.
    const sparklineWidth = boardWidth;
    const evalColWidth = 180;
    // Keep badges and main row aligned to the board (eval bar floats to the right).
    const layoutWidth = boardWidth;
    const graphOffset = 0;
    const keyframes = `
    @keyframes popFade {
      0% { transform: scale(0.9); opacity: 0; }
      30% { transform: scale(1.02); opacity: 1; }
      100% { transform: scale(1); opacity: 1; }
    }
  `;
    /* --------------------------------- Render --------------------------------- */
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center', justifyContent: 'center', width: '100%', maxWidth: '98vw', margin: '0 auto' }, children: [_jsx("style", { children: keyframes }), _jsxs("div", { style: { display: 'flex', alignItems: 'flex-start', width: layoutWidth, margin: '0 auto', gap: 12 }, children: [_jsx("div", { style: { flex: '1 1 0%', display: 'flex', justifyContent: 'flex-start', marginLeft: 6 }, children: _jsx(PlayerBadge, { side: "white", name: whiteName, acc: whiteAcc, estElo: whiteEstElo }) }), _jsx("div", { style: { flex: '1 1 0%', display: 'flex', justifyContent: 'flex-end', marginRight: Math.max(0, evalColWidth * 0.45) }, children: _jsx(PlayerBadge, { side: "black", name: blackName, acc: blackAcc, estElo: blackEstElo }) })] }), _jsxs("div", { style: { position: 'relative', display: 'flex', flexDirection: 'row', gap: 18, alignItems: 'flex-start', justifyContent: 'center', width: layoutWidth, margin: '0 auto', overflow: 'visible' }, children: [_jsxs("div", { ref: containerRef, style: { position: 'relative', width: boardWidth, paddingBottom: 50 }, children: [_jsx(Chessboard, { id: "analysis", position: fen, boardOrientation: orientation, boardWidth: boardWidth, animationDuration: 150, customBoardStyle: { margin: '0 auto', overflow: 'visible' }, customArrows: arrows, customSquareStyles: mergedSquareStyles, onPieceDrop: onPieceDrop, onSquareClick: handleSquareClick }), badgePos && (_jsx("div", { style: {
                                    position: 'absolute',
                                    left: badgePos.left,
                                    top: badgePos.top,
                                    width: badgeSize,
                                    height: badgeSize,
                                    pointerEvents: 'none',
                                }, children: _jsx(RenderBadge, { tag: overlayTag, size: badgeSize }) }))] }), _jsx("div", { style: { position: 'absolute', left: boardWidth + 18, top: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, minWidth: evalColWidth }, children: _jsx("div", { style: {
                                display: 'flex',
                                alignItems: 'flex-start',
                                justifyContent: 'flex-start',
                                height: boardWidth, // align column height to board
                                minWidth: evalColWidth,
                            }, children: _jsx(EvalBar, { cp: evalCpDisplay, pending: Boolean(evalPending), height: evalBarHeight }) }) })] }), props.showEvalGraph !== false && evalSeries && evalSeries.length > 0 ? (_jsx("div", { style: { width: sparklineWidth, padding: 12, border: '1px solid #3a3a3a', borderRadius: 12, alignSelf: 'center', marginLeft: graphOffset, marginRight: graphOffset }, children: _jsx(EvalSparkline, { series: evalSeries, height: 138, onClickIndex: (i) => props.onRebuildTo(i + 1) }) })) : null, _jsxs("div", { style: { ...ui.col, width: boardWidth, gap: 12, marginTop: 6 }, children: [outcomeText ? (_jsx("div", { style: { fontSize: 15, padding: '10px 12px', borderRadius: 10, background: '#1f2a37', color: '#e5e7eb', border: '1px solid #334155', animation: 'popFade 0.7s ease' }, children: outcomeText })) : null, _jsx("div", { style: { width: '100%', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 12 }, children: _jsxs("div", { style: { padding: '12px 14px', borderRadius: 12, border: '1px solid #1f2a3a', background: '#0c111b', boxShadow: '0 10px 26px rgba(0,0,0,.35)', display: 'flex', flexDirection: 'column', gap: 10 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }, children: [_jsxs("span", { style: { ...ui.pill, background: '#0f172a', borderColor: '#203046' }, children: [_jsx(Icon, { name: "clock", size: 18 }), "Time"] }), _jsx("select", { value: timeControlMinutes ?? 10, onChange: (e) => onTimeControlChange?.(Number(e.target.value) || 10), style: ui.select, disabled: isGameOver, children: [3, 5, 10, 15, 30].map((m) => _jsxs("option", { value: m, children: [m, " min"] }, m)) })] }), _jsxs("button", { style: btnStyle(isGameOver || clockRunning), onClick: onBeginMatch, disabled: isGameOver || clockRunning, children: [_jsx(Icon, { name: "play", size: 18 }), matchStarted ? 'Resume' : 'Begin'] })] }), _jsxs("div", { style: { display: 'flex', gap: 10, flexWrap: 'wrap' }, children: [_jsxs("div", { style: ui.pill, children: [_jsx(Icon, { name: "kingW", size: 18 }), "White: ", clockLabel(clockMs?.w)] }), _jsxs("div", { style: { ...ui.pill, background: '#0c1322' }, children: [_jsx(Icon, { name: "kingB", size: 18 }), "Black: ", clockLabel(clockMs?.b)] }), _jsxs("div", { style: { ...ui.pill, background: '#0d1726', borderStyle: 'dashed', borderColor: '#203046', color: '#9fb4d2' }, children: [_jsx(Icon, { name: clockRunning ? 'play' : 'clock', size: 18 }), clockRunning ? 'Clock running' : (matchStarted ? 'Paused' : 'Not started')] })] })] }) }), _jsxs("div", { style: ui.controlGrid, children: [_jsxs("button", { style: btnStyle(ply === 0), onClick: () => onRebuildTo(0), disabled: ply === 0, children: [_jsx(Icon, { name: "rewind", size: 22 }), "First"] }), _jsxs("button", { style: btnStyle(ply === 0), onClick: () => onRebuildTo(Math.max(0, ply - 1)), disabled: ply === 0, children: [_jsx(Icon, { name: "back", size: 22 }), "Back"] }), _jsxs("button", { style: btnStyle(ply >= movesUci.length), onClick: () => onRebuildTo(Math.min(movesUci.length, ply + 1)), disabled: ply >= movesUci.length, children: [_jsx(Icon, { name: "forward", size: 22 }), "Forward"] }), _jsxs("button", { style: btnStyle(ply >= movesUci.length), onClick: () => onRebuildTo(movesUci.length), disabled: ply >= movesUci.length, children: [_jsx(Icon, { name: "end", size: 22 }), "End"] }), _jsxs("button", { style: btnStyle(false), onClick: onNewGame, children: [_jsx(Icon, { name: "plus", size: 22 }), "New"] })] }), _jsxs("div", { style: ui.controlGrid, children: [_jsxs("button", { style: btnStyle(engineBusy || isGameOver), onClick: onEngineMove, disabled: engineBusy || isGameOver, children: [_jsx(Icon, { name: "cpu", size: 22 }), "Engine Move"] }), _jsxs("button", { style: btnStyle(isGameOver || !onOfferDraw), onClick: () => onOfferDraw?.(), disabled: isGameOver || !onOfferDraw, children: [_jsx(Icon, { name: "handshake", size: 22 }), "Offer Draw"] }), _jsxs("button", { style: btnStyle(isGameOver || !onResign), onClick: onResign, disabled: isGameOver || !onResign, children: [_jsx(Icon, { name: "flag", size: 22 }), "Resign"] }), _jsxs("label", { style: { ...ui.toggle, opacity: isGameOver ? 0.55 : 1, cursor: isGameOver ? 'not-allowed' : 'pointer' }, children: [_jsx("input", { type: "checkbox", checked: autoReply, onChange: e => setAutoReply(e.target.checked), disabled: isGameOver, style: { accentColor: '#22c55e' } }), _jsx(Icon, { name: "repeat", size: 22 }), "Auto reply"] }), _jsxs("button", { style: btnStyle(engineBusy || !onOrientationChange || isGameOver), onClick: () => {
                                    onOrientationChange?.('black');
                                    if (ply === 0)
                                        onEngineMove();
                                }, disabled: engineBusy || !onOrientationChange || isGameOver, title: "Flip to Black and, if at start, let engine make the first move", children: [_jsx(Icon, { name: "knight", size: 22 }), "Play as Black"] }), _jsx("button", { style: { ...ui.btnIcon, opacity: !onOrientationChange ? 0.55 : 1, cursor: !onOrientationChange ? 'not-allowed' : 'pointer' }, onClick: () => onOrientationChange?.(orientation === 'white' ? 'black' : 'white'), disabled: !onOrientationChange, title: "Flip board", "aria-label": "Flip board", children: _jsx(Icon, { name: "flip", size: 22 }) })] })] })] }));
}
