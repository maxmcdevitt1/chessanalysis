import { useCallback, useState } from 'react';
import { generateCoachNotes } from '../CommentaryServiceOllama';
import type { CoachInputs, CoachMoveNote, CoachSections } from '../types/coach';

export function useCoach() {
  const [sections, setSections] = useState<CoachSections | null>(null);
  const [moveNotes, setMoveNotes] = useState<CoachMoveNote[]>([]);
  const [isRunning, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (inputs: CoachInputs) => {
    setRunning(true);
    setError(null);
    try {
      const res = await generateCoachNotes(inputs);
      if (!res || (res as any).offline) {
        const reason = (res as any)?.reason || 'offline';
        setSections(null);
        setMoveNotes([]);
        setError(`Coach unavailable (${reason})`);
        return null;
      }
      setSections(res.sections ?? null);
      setMoveNotes(res.moves ?? []);
      return res.sections ?? null;
    } catch (err: any) {
      setSections(null);
      setMoveNotes([]);
      setError(err?.message ?? String(err));
      throw err;
    } finally {
      setRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setSections(null);
    setMoveNotes([]);
    setError(null);
  }, []);

  return { sections, moveNotes, isRunning, error, run, reset };
}
