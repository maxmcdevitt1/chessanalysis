import { useMemo } from 'react';
import type { CoachMoveNote } from '../types/coach';

export function useCoachNoteForPly(ply: number, notes: CoachMoveNote[] | null | undefined) {
  return useMemo(() => {
    const arr = Array.isArray(notes) ? notes : [];
    if (!arr.length || ply <= 0) return null;
    const idx = Math.max(0, ply - 1);
    const pick = (predicate: (note: CoachMoveNote) => boolean) =>
      arr.find((n) => n.moveNo > 1 && predicate(n)); // skip trivia for move 1
    const exact = pick((n) => n.moveIndex === idx);
    if (exact) return exact;
    const near = pick((n) => Math.abs(n.moveIndex - idx) === 1);
    if (near) return near;
    if (idx <= 1) {
      const isWhite = idx % 2 === 0;
      const fallbackTexts = [
        'Nice start — keep building your center.',
        'Solid reply — stay flexible.',
      ];
      return {
        moveIndex: idx,
        moveNo: 1,
        side: isWhite ? 'W' : 'B',
        san: '',
        text: fallbackTexts[idx] ?? fallbackTexts[fallbackTexts.length - 1],
      };
    }
    return null;
  }, [ply, notes]);
}
