import { useCallback, useEffect, useState } from 'react';
export function useMatchClock({ gameRef, gameOver, setGameOver, setAutoReply, }) {
    const [timeControlMinutes, setTimeControlMinutes] = useState(10);
    const [clockMs, setClockMs] = useState({ w: 10 * 60000, b: 10 * 60000 });
    const [clockRunning, setClockRunning] = useState(false);
    const [matchStarted, setMatchStarted] = useState(false);
    const resetClocksToStart = useCallback(() => {
        const ms = Math.max(1, timeControlMinutes) * 60000;
        setClockMs({ w: ms, b: ms });
        setClockRunning(false);
        setMatchStarted(false);
    }, [timeControlMinutes]);
    useEffect(() => { resetClocksToStart(); }, [resetClocksToStart]);
    useEffect(() => { if (gameOver)
        setClockRunning(false); }, [gameOver]);
    useEffect(() => {
        if (!clockRunning || gameOver)
            return;
        const tickMs = 200;
        const id = setInterval(() => {
            const turn = gameRef.current.turn?.() === 'b' ? 'b' : 'w';
            setClockMs((prev) => {
                const nextVal = Math.max(0, prev[turn] - tickMs);
                const next = { ...prev, [turn]: nextVal };
                if (nextVal <= 0) {
                    const winner = turn === 'w' ? 'Black' : 'White';
                    setGameOver({ reason: 'flag', winner });
                    setClockRunning(false);
                    setAutoReply(false);
                }
                return next;
            });
        }, tickMs);
        return () => clearInterval(id);
    }, [clockRunning, gameOver, gameRef, setGameOver, setAutoReply]);
    const startClock = useCallback(() => {
        if (!matchStarted)
            return;
        setClockRunning(true);
    }, [matchStarted]);
    const pauseClock = useCallback(() => setClockRunning(false), []);
    const markMatchNotStarted = useCallback(() => { setClockRunning(false); setMatchStarted(false); }, []);
    const beginMatch = useCallback(() => {
        if (!matchStarted) {
            resetClocksToStart();
            setMatchStarted(true);
            setGameOver(null);
        }
        setClockRunning(true);
    }, [matchStarted, resetClocksToStart, setGameOver]);
    const resignMatch = useCallback(() => {
        if (gameOver)
            return;
        const turn = gameRef.current.turn?.() === 'b' ? 'Black' : 'White';
        const winner = turn === 'White' ? 'Black' : 'White';
        setGameOver({ reason: 'resign', winner });
        setClockRunning(false);
        setAutoReply(false);
    }, [gameOver, gameRef, setGameOver, setAutoReply]);
    return {
        timeControlMinutes,
        setTimeControlMinutes,
        clockMs,
        clockRunning,
        matchStarted,
        startClock,
        pauseClock,
        resetClocksToStart,
        markMatchNotStarted,
        beginMatch,
        resignMatch,
    };
}
