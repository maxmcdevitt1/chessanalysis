import { useEffect, useState } from 'react';
import { getString, setString } from '../persist';
import { setPlayElo } from '../botPicker';
import { setStrength } from '../bridge';
import { bandById, bandPlayElo, DEFAULT_STRENGTH_BAND_ID } from '../strengthBands';
const ENGINE_STRENGTH_KEY = 'engineStrengthBand';
/**
 * Persist engine strength band, mirror Elo to localStorage, and push to the picker-only Elo.
 */
export function useEngineStrength() {
    const [engineBand, setEngineBand] = useState(() => getString(ENGINE_STRENGTH_KEY, DEFAULT_STRENGTH_BAND_ID));
    useEffect(() => {
        setString(ENGINE_STRENGTH_KEY, engineBand);
    }, [engineBand]);
    useEffect(() => {
        const elo = bandPlayElo(engineBand);
        localStorage.setItem('engineElo', String(elo));
        setPlayElo(elo);
        let cancelled = false;
        const apply = async () => {
            try {
                await setStrength(elo);
            }
            catch {
                // swallow IPC failures; UI already reflects elo slider
            }
        };
        // Defer slightly so rapid band toggles coalesce.
        const timer = setTimeout(() => {
            if (!cancelled)
                apply();
        }, 150);
        return () => {
            cancelled = true;
            clearTimeout(timer);
        };
    }, [engineBand]);
    return {
        engineBand,
        setEngineBand,
        currentBand: bandById(engineBand),
    };
}
