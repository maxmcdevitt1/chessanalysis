// webui/src/useCoach.ts
import { useState, useCallback } from 'react';
export function useCoach() {
    const [notes, setNotes] = useState(null);
    const [busy, setBusy] = useState(false);
    const [err, setErr] = useState(null);
    const run = useCallback(async (inputs) => {
        setBusy(true);
        setErr(null);
        try {
            // @ts-ignore
            const res = await window.coach?.generate(inputs);
            if (!res || res.offline) {
                setErr('Coach offline');
                setNotes(null);
            }
            else
                setNotes(res.notes || null);
        }
        catch (e) {
            setErr(String(e?.message || e));
        }
        finally {
            setBusy(false);
        }
    }, []);
    return { notes, busy, err, run };
}
