export class Navigator {
    constructor(opts) {
        this.ply = 0;
        this.totalPlies = opts.totalPlies;
        this.onChange = opts.onChange;
    }
    setBounds(totalPlies) {
        this.totalPlies = Math.max(0, totalPlies | 0);
        if (this.ply > this.totalPlies)
            this.setPly(this.totalPlies);
    }
    getPly() { return this.ply; }
    getTotal() { return this.totalPlies; }
    setPly(n) {
        const clamped = Math.max(0, Math.min(n | 0, this.totalPlies));
        if (clamped !== this.ply) {
            this.ply = clamped;
            this.onChange(this.ply);
        }
    }
    next() { this.setPly(this.ply + 1); }
    prev() { this.setPly(this.ply - 1); }
    home() { this.setPly(0); }
    end() { this.setPly(this.totalPlies); }
}
