import { Chess } from '../chess-compat';
function uciToMove(uci) {
    const from = uci.slice(0, 2);
    const to = uci.slice(2, 4);
    const promotion = uci.length > 4 ? uci[4] : undefined;
    return { from, to, promotion };
}
export function computeSANForHistory(uciHistory) {
    const chess = new Chess();
    const san = [];
    for (const uci of uciHistory) {
        const move = chess.move(uciToMove(uci));
        if (!move) {
            san.push('??');
            continue;
        }
        san.push(move.san);
    }
    return san;
}
