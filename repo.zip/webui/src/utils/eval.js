export function mergeEvalsDistinct(list) {
    let prevKey = '';
    return list.map((e) => {
        if (!e)
            return e;
        const key = e.mate !== undefined ? `m${e.pov}${e.mate}` : `c${e.pov}${e.cp}`;
        if (key === prevKey)
            return undefined;
        prevKey = key;
        return e;
    });
}
