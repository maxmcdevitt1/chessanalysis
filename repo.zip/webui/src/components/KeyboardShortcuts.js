import { useEffect } from 'react';
export default function KeyboardShortcuts({ navigator, enabled = true }) {
    useEffect(() => {
        if (!enabled)
            return;
        const onKey = (e) => {
            const tgt = e.target;
            const isTyping = tgt && (tgt.tagName === 'INPUT' || tgt.tagName === 'TEXTAREA' || tgt.isContentEditable);
            if (isTyping)
                return;
            if (e.key === 'ArrowRight') {
                navigator.next();
                e.preventDefault();
            }
            else if (e.key === 'ArrowLeft') {
                navigator.prev();
                e.preventDefault();
            }
            else if (e.key === 'Home') {
                navigator.home();
                e.preventDefault();
            }
            else if (e.key === 'End') {
                navigator.end();
                e.preventDefault();
            }
        };
        window.addEventListener('keydown', onKey, { passive: false });
        return () => window.removeEventListener('keydown', onKey);
    }, [navigator, enabled]);
    return null;
}
