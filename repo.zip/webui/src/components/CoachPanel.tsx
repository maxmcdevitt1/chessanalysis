import React from 'react';
import type { CoachSections } from '../types/coach';

export type CoachPanelProps = {
  sections?: CoachSections | null;
  busy?: boolean;
  error?: string | null;
  onGenerate?: () => void;
};

function SectionCard({ title, content }: { title: string; content?: string | React.ReactNode }) {
  const text = typeof content === 'string' ? content.trim() : content;
  if (!text) return null;
  return (
    <div
      style={{
        border: '1px solid #2f3545',
        borderRadius: 10,
        padding: '10px 12px',
        background: '#0c1324',
        color: '#e5e7eb',
        fontSize: 14,
        lineHeight: '20px',
      }}
    >
      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 6 }}>{title}</div>
      {content}
    </div>
  );
}

function KeyList({ items }: { items?: string[] }) {
  if (!items || !items.length) return null;
  return (
    <ul style={{ margin: 0, paddingLeft: 18 }}>
      {items.map((line, idx) => (
        <li key={`km-${idx}`} style={{ marginBottom: 4 }}>{line}</li>
      ))}
    </ul>
  );
}

export default function CoachPanel({ sections, busy = false, error, onGenerate }: CoachPanelProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ fontWeight: 600, fontSize: 16 }}>Coach</div>
        <button
          style={{
            padding: '8px 12px',
            borderRadius: 8,
            border: '1px solid #333',
            background: busy ? '#2a2a2a' : '#1f1f1f',
            color: '#eee',
            cursor: busy ? 'default' : 'pointer',
            opacity: busy ? 0.6 : 1,
          }}
          onClick={() => !busy && onGenerate?.()}
          disabled={busy}
        >
          {busy ? 'Generating…' : 'Generate notes'}
        </button>
      </div>
      {error && <div style={{ fontSize: 13, color: '#f28b3c' }}>{error}</div>}
      {busy && <div style={{ fontSize: 13, color: '#bdbdbd' }}>The coach is analysing this game…</div>}
      {sections ? (
        <>
          <SectionCard title="Executive Summary" content={sections.executiveSummary} />
          <SectionCard title="Opening Review" content={sections.openingReview} />
          <SectionCard title="Middlegame Review" content={sections.middlegameReview} />
          <SectionCard title="Endgame Review" content={sections.endgameReview} />
          <SectionCard title="Key Moments & Turning Points" content={<KeyList items={sections.keyMoments} />} />
          <SectionCard title="Three Most Important Lessons" content={
            <ol style={{ margin: 0, paddingLeft: 18 }}>
              {(sections.lessons || []).map((line, idx) => (
                <li key={`lesson-${idx}`} style={{ marginBottom: 4 }}>{line}</li>
              ))}
            </ol>
          } />
        </>
      ) : (
        <div style={{ fontSize: 13, color: '#8f8f8f' }}>
          No coach notes yet. Generate notes to see a full premium-style review of this game.
        </div>
      )}
    </div>
  );
}
