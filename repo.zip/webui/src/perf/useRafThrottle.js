import { useRef, useCallback } from 'react';
export function useRafThrottle(fn) {
    const rafRef = useRef(null);
    const lastArgs = useRef(null);
    const cb = useCallback((...args) => {
        lastArgs.current = args;
        if (rafRef.current != null)
            return;
        rafRef.current = requestAnimationFrame(() => {
            rafRef.current = null;
            const a = lastArgs.current;
            lastArgs.current = null;
            // @ts-ignore
            fn.apply(null, a ?? []);
        });
    }, [fn]);
    return cb;
}
