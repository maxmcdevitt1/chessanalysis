// Human-like move picker built on top of a UCI engine wrapper.
// Usage:
//   import { setEngine, pickMove } from './botPicker';
//   setEngine(engineInstance);
//   const move = await pickMove(fen, 1400, { moves: movesSoFar });
import { Chess } from './chess-compat';
import openingBookSource from './data/beginneropenings.json';
let engine = null;
export function setEngine(e) {
    engine = e;
}
// Prevent overlapping analyse() calls (some engines misbehave otherwise)
let inFlight = null;
let lastMultiPv = -1;
const THREADS = 2;
const HASH_MB = 128;
const DEFAULT_BOOK_PLY = 12;
function bandFromElo(elo) {
    const e = clampElo(elo);
    if (e <= 800)
        return 'beginner';
    if (e <= 1000)
        return 'developing';
    if (e <= 1300)
        return 'intermediate';
    if (e <= 1700)
        return 'advanced';
    return 'expert';
}
const BAND_CFG = {
    beginner: { movetimeFloorMs: 150, multipvCap: 3, baseMaxDrop: 700, k: 0.024, bookMaxPlies: 5, bookTopLines: 3 },
    developing: { movetimeFloorMs: 170, multipvCap: 2, baseMaxDrop: 650, k: 0.0135, bookMaxPlies: 6, bookTopLines: 2 },
    intermediate: { movetimeFloorMs: 160, multipvCap: 2, baseMaxDrop: 480, k: 0.012, bookMaxPlies: 10, bookTopLines: 3 },
    advanced: { movetimeFloorMs: 130, multipvCap: 2, baseMaxDrop: 300, k: 0.009, bookMaxPlies: 12, bookTopLines: 4 },
    expert: { movetimeFloorMs: 120, multipvCap: 1, baseMaxDrop: 220, k: 0.006, bookMaxPlies: 14, bookTopLines: 6 },
};
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const FALLBACK_ELO = 1500;
let baselineElo = FALLBACK_ELO;
function readStoredElo() {
    try {
        if (typeof window === 'undefined' || typeof window.localStorage === 'undefined')
            return null;
        const stored = Number(window.localStorage.getItem('engineElo') || '');
        return Number.isFinite(stored) ? stored : null;
    }
    catch {
        return null;
    }
}
const clampElo = (elo) => {
    const raw = (typeof elo === 'number' && Number.isFinite(elo)) ? elo : baselineElo;
    return clamp(Math.round(raw), 400, 2500);
};
let PLAY_ELO = clampElo(baselineElo);
function seedPlayEloFromStorage() {
    const stored = readStoredElo();
    if (stored != null) {
        baselineElo = stored;
        PLAY_ELO = clampElo(stored);
    }
}
seedPlayEloFromStorage();
export function setPlayElo(elo) { PLAY_ELO = clampElo(elo); }
export function getPlayElo() { return PLAY_ELO; }
const baseMove = (uci) => String(uci || '').slice(0, 4).toLowerCase();
function kForElo(eloRaw) {
    const band = bandFromElo(eloRaw);
    return BAND_CFG[band].k;
}
function movetimeForElo(eloRaw) {
    const e = clampElo(eloRaw);
    const points = [
        [400, 120],
        [600, 160],
        [800, 210],
        [1000, 320],
        [1300, 500],
        [1700, 850],
        [2000, 1200],
        [2300, 1600],
        [2500, 1900],
    ];
    for (let i = 0; i < points.length - 1; i++) {
        const [e0, t0] = points[i];
        const [e1, t1] = points[i + 1];
        if (e >= e0 && e <= e1) {
            const k = (e - e0) / (e1 - e0);
            return Math.round(t0 + k * (t1 - t0));
        }
    }
    return points[points.length - 1][1];
}
// MultiPV depends on both Elo and per-move think time (ms).
function multiPvFor(elo, ms) {
    const band = bandFromElo(elo);
    if (ms < 80)
        return 1;
    let mpv = band === 'beginner' ? (ms < 200 ? 2 : 3) :
        band === 'developing' ? 2 :
            band === 'intermediate' ? 2 :
                band === 'advanced' ? 2 : 1;
    return Math.min(mpv, BAND_CFG[band].multipvCap);
}
// ===== Developing band guardrail (800–1000 Elo) =====
const DEV_RANGE = { lo: 800, hi: 1000 };
const DEV_TARGET_GAP_CP = 140;
const DEV_MIN_MS = 150;
const DEV_MAX_MPV = 2;
const DEV_MIN_DROP = 80;
const DEV_MAX_DROP = 720;
const DEV_MIN_KSCALE = 0.70;
const DEV_MAX_KSCALE = 1.15;
let devAvgGap = NaN;
let devKScale = 1.0;
let devDropAdj = 0;
function devInBand(elo) {
    return elo >= DEV_RANGE.lo && elo <= DEV_RANGE.hi;
}
function devUpdateAfterPick(gapCp) {
    devAvgGap = Number.isFinite(devAvgGap) ? (devAvgGap * 0.9 + gapCp * 0.1) : gapCp;
    const err = devAvgGap - DEV_TARGET_GAP_CP;
    if (!Number.isFinite(err) || err === 0)
        return;
    const sign = Math.sign(err);
    devKScale = Math.max(DEV_MIN_KSCALE, Math.min(DEV_MAX_KSCALE, devKScale * (1 - sign * 0.02)));
    devDropAdj = Math.max(DEV_MIN_DROP - 120, Math.min(DEV_MAX_DROP - 90, devDropAdj - sign * 2));
}
function devTune({ elo, ms, multiPv, baseMaxDrop, baseK }) {
    if (!devInBand(elo))
        return { ms, multiPv, maxDrop: baseMaxDrop, k: baseK };
    const tunedMs = Math.max(ms, DEV_MIN_MS);
    const tunedMpv = Math.min(multiPv, DEV_MAX_MPV);
    const drop = Math.max(DEV_MIN_DROP, Math.min(DEV_MAX_DROP, baseMaxDrop + devDropAdj));
    const k = Math.max(baseK * DEV_MIN_KSCALE, Math.min(baseK * DEV_MAX_KSCALE, baseK * devKScale));
    return { ms: tunedMs, multiPv: tunedMpv, maxDrop: drop, k };
}
function toUciMoves(moves) {
    if (!moves || !moves.length)
        return [];
    const out = [];
    try {
        const g = new Chess();
        for (const raw of moves) {
            const tok = String(raw || '').trim();
            if (!tok)
                break;
            // Allow direct UCI tokens (a2a4, a7a8q) as well as SAN.
            if (/^[a-h][1-8][a-h][1-8][nbrq]?$/i.test(tok)) {
                const uci = tok.toLowerCase();
                const mv = { from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] };
                if (!g.move(mv))
                    break;
                out.push(uci);
            }
            else {
                const mv = g.move(tok, { sloppy: true });
                if (!mv)
                    break;
                out.push(`${mv.from}${mv.to}${mv.promotion || ''}`);
            }
        }
    }
    catch {
        return [];
    }
    return out;
}
let BOOK_CACHE = null;
function loadOpeningBook() {
    if (BOOK_CACHE)
        return BOOK_CACHE;
    const src = openingBookSource || {};
    const rows = Array.isArray(src.openings) ? src.openings : [];
    const lines = [];
    for (const opening of rows) {
        const side = String(opening.side || '').toLowerCase().startsWith('b') ? 'b' : 'w';
        const openingWeight = Number.isFinite(opening.weight) && opening.weight > 0 ? Number(opening.weight) : 1;
        if (!Array.isArray(opening.lines))
            continue;
        for (const line of opening.lines) {
            const uciMoves = toUciMoves(line.moves);
            if (!uciMoves.length)
                continue;
            lines.push({
                eco: opening.eco || '',
                name: opening.name || '',
                variation: line.variation,
                side,
                openingWeight,
                lineWeight: Number.isFinite(line.weight) && line.weight > 0 ? Number(line.weight) : 1,
                movesUci: uciMoves,
            });
        }
    }
    BOOK_CACHE = lines;
    return BOOK_CACHE;
}
function pickWeighted(entries) {
    const list = entries.filter((e) => Number.isFinite(e.weight) && e.weight > 0);
    if (!list.length)
        return null;
    const total = list.reduce((s, e) => s + e.weight, 0);
    let r = Math.random() * total;
    for (const e of list) {
        r -= e.weight;
        if (r <= 0)
            return e.value;
    }
    return list[list.length - 1].value;
}
function historyMatches(line, history) {
    if (history.length > line.length)
        return false;
    for (let i = 0; i < history.length; i++) {
        if (baseMove(line[i]) !== baseMove(history[i]))
            return false;
    }
    return true;
}
function pickBookMove(side, history, fen, elo) {
    const band = bandFromElo(elo);
    const favorCommon = band === 'beginner' || band === 'developing' || band === 'intermediate';
    const bandMax = BAND_CFG[band].bookMaxPlies;
    const maxBook = Math.max(5, Math.round(Math.min(14, 4 + (clampElo(elo) - 600) / 80)));
    const minPlies = elo >= 1000 ? 10 : 0; // ensure ≥10 lines per side at 1000+
    const bookLimit = Math.max(minPlies, Math.min(Math.max(0, bandMax), Math.min(maxBook, DEFAULT_BOOK_PLY)));
    if (history.length >= bookLimit)
        return null;
    const book = loadOpeningBook();
    const candidates = book.filter((l) => l.side === side && l.movesUci.length > history.length && historyMatches(l.movesUci, history));
    if (!candidates.length)
        return null;
    // Step 1: pick opening by opening.weight
    const grouped = new Map();
    for (const line of candidates) {
        const key = `${line.side}|${line.eco}|${line.name}`;
        const existing = grouped.get(key);
        if (existing) {
            existing.lines.push(line);
        }
        else {
            grouped.set(key, { weight: line.openingWeight, lines: [line] });
        }
    }
    const openings = Array.from(grouped.values()).map((v) => ({ weight: v.weight ?? 1, value: v }));
    const openingPick = favorCommon ? ((openings
        .slice()
        .sort((a, b) => (b.weight ?? 1) - (a.weight ?? 1))
        .shift()?.value) ?? null) : pickWeighted(openings);
    if (!openingPick)
        return null;
    // Step 2: pick line by line.weight inside the chosen opening.
    const variants = openingPick.lines.map((ln) => ({ weight: ln.lineWeight, value: ln }));
    const topN = BAND_CFG[band].bookTopLines;
    const limited = variants
        .slice()
        .sort((a, b) => (b.weight ?? 1) - (a.weight ?? 1))
        .slice(0, Math.max(1, topN));
    const linePick = favorCommon ? ((limited[0]?.value) ?? null) : pickWeighted(limited);
    if (!linePick)
        return null;
    const uci = linePick.movesUci[history.length];
    if (!uci)
        return null;
    try {
        const g = new Chess(fen);
        const parsed = { from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] || undefined };
        const mv = g.move(parsed);
        if (!mv)
            return null;
        return `${mv.from}${mv.to}${mv.promotion || ''}`;
    }
    catch {
        return null;
    }
}
function evalForMover(score) {
    if (!score)
        return null;
    if (typeof score.mate === 'number' && isFinite(score.mate)) {
        const cp = 10000 - Math.min(99, Math.abs(score.mate)) * 100;
        return score.mate >= 0 ? cp : -cp;
    }
    if (typeof score.cp === 'number' && isFinite(score.cp)) {
        return score.cp;
    }
    return null;
}
function toMoverCands(raw) {
    const out = [];
    for (const entry of raw) {
        const cp = evalForMover(entry);
        if (typeof cp !== 'number' || !Number.isFinite(cp))
            continue;
        out.push({ uci: entry.uci, cp, pv: entry.pv });
    }
    return out;
}
function imperfectionProfileFor(elo) {
    const e = clampElo(elo);
    if (e <= 600)
        return { rate: 0.60, minDrop: 90, maxDrop: 600, randomLegalRate: 0.22, takeWorst: 4 };
    if (e <= 800)
        return { rate: 0.46, minDrop: 80, maxDrop: 600, randomLegalRate: 0.14, takeWorst: 3 };
    if (e <= 1000)
        return { rate: 0.38, minDrop: 70, maxDrop: 500, randomLegalRate: 0.08, takeWorst: 3 };
    if (e <= 1300)
        return { rate: 0.18, minDrop: 45, maxDrop: 280, randomLegalRate: 0.04, takeWorst: 2 };
    if (e <= 1700)
        return { rate: 0.08, minDrop: 35, maxDrop: 160, randomLegalRate: 0.02, takeWorst: 2 };
    if (e <= 2000)
        return { rate: 0.04, minDrop: 25, maxDrop: 110, randomLegalRate: 0.00, takeWorst: 2 };
    if (e <= 2300)
        return { rate: 0.02, minDrop: 20, maxDrop: 80, randomLegalRate: 0.00, takeWorst: 2 };
    return null;
}
function randomLegalMove(fen, exclude = new Set()) {
    try {
        const g = new Chess(fen);
        const moves = g.moves({ verbose: true })
            .map((m) => `${m.from}${m.to}${m.promotion || ''}`)
            .filter((uci) => !exclude.has(uci));
        if (!moves.length)
            return null;
        return moves[Math.floor(Math.random() * moves.length)];
    }
    catch {
        return null;
    }
}
function maybeImperfectMove(fen, cands, bestCp, elo) {
    const profile = imperfectionProfileFor(elo);
    if (!profile)
        return null;
    if (Math.random() > profile.rate)
        return null;
    const sorted = cands
        .map((c) => ({ ...c, drop: bestCp - c.cp }))
        .filter((c) => c.drop > 0)
        .sort((a, b) => b.drop - a.drop);
    const targetPool = sorted.filter((c) => c.drop >= profile.minDrop && (profile.maxDrop <= 0 || c.drop <= profile.maxDrop));
    const selectionPool = targetPool.length ? targetPool : sorted;
    if (selectionPool.length) {
        const span = Math.max(1, Math.min(selectionPool.length, profile.takeWorst));
        const pool = selectionPool.slice(0, span);
        const pick = pool[Math.floor(Math.random() * pool.length)];
        if (pick)
            return pick.uci;
    }
    if (profile.randomLegalRate > 0 && Math.random() < profile.randomLegalRate) {
        const exclude = new Set(cands.map((c) => c.uci));
        const random = randomLegalMove(fen, exclude);
        if (random)
            return random;
    }
    return null;
}
export async function pickMove(fen, targetElo, opts = {}) {
    if (inFlight)
        return inFlight;
    inFlight = (async () => {
        if (!engine)
            throw new Error('Engine not set. Call setEngine() first.');
        const movesSoFar = Array.isArray(opts.moves) ? opts.moves : [];
        const sideToMove = (() => {
            try {
                return new Chess(fen).turn();
            }
            catch {
                return 'w';
            }
        })();
        const desiredElo = (typeof targetElo === 'number' && Number.isFinite(targetElo)) ? targetElo : getPlayElo();
        const elo = clampElo(desiredElo);
        setPlayElo(elo); // keep global in sync for callers that rely on implicit target
        const bookMove = pickBookMove(sideToMove, movesSoFar, fen, elo);
        if (bookMove)
            return bookMove;
        const band = bandFromElo(elo);
        const msBudget = movetimeForElo(elo);
        let ms = Math.max(msBudget, BAND_CFG[band].movetimeFloorMs);
        let multiPv = multiPvFor(elo, ms);
        const baseMaxDrop = BAND_CFG[band].baseMaxDrop;
        const baseK = kForElo(elo);
        const devTuned = devTune({ elo, ms, multiPv, baseMaxDrop, baseK });
        ms = devTuned.ms;
        multiPv = devTuned.multiPv;
        let maxDrop = devTuned.maxDrop;
        let k = devTuned.k;
        const setOpts = {
            UCI_LimitStrength: true,
            UCI_Elo: elo,
            Threads: THREADS,
            Hash: HASH_MB,
            Ponder: false,
        };
        if (multiPv !== lastMultiPv) {
            setOpts.MultiPV = multiPv;
            lastMultiPv = multiPv;
        }
        await engine.setOptions(setOpts);
        const info = await (async () => {
            const primary = await engine.analyse({ fen, movetimeMs: ms, multiPv, finalOnly: true });
            if (primary?.cands?.length)
                return primary;
            const retryMs = Math.max(ms + 120, 200);
            if (multiPv !== 1) {
                await engine.setOptions({ MultiPV: 1 });
                lastMultiPv = 1;
            }
            return engine.analyse({ fen, movetimeMs: retryMs, multiPv: 1, finalOnly: true });
        })();
        const cands = toMoverCands(info.cands || []).sort((a, b) => b.cp - a.cp);
        if (!cands.length) {
            const fallback = randomLegalMove(fen);
            if (fallback) {
                inFlight = null;
                return fallback;
            }
            throw new Error('No candidates returned from engine');
        }
        const bestCp = cands[0].cp;
        if (elo <= 1400) {
            console.debug('[intermediate]', {
                elo,
                ms,
                multiPv,
                bestCp,
                top3: cands.slice(0, 3),
            });
        }
        const pool = cands.filter((c) => (bestCp - c.cp) <= maxDrop);
        const pickPool = pool.length ? pool : cands;
        const imperfectChoice = maybeImperfectMove(fen, pickPool, bestCp, elo);
        if (imperfectChoice)
            return imperfectChoice;
        const weights = pickPool.map((c) => Math.exp(-k * Math.max(0, bestCp - c.cp)));
        const total = weights.reduce((a, b) => a + b, 0);
        let choice = pickPool[pickPool.length - 1];
        let r = Math.random() * total;
        for (let i = 0; i < pickPool.length; i++) {
            r -= weights[i];
            if (r <= 0) {
                choice = pickPool[i];
                break;
            }
        }
        if (devInBand(elo))
            devUpdateAfterPick(bestCp - choice.cp);
        inFlight = null;
        return choice.uci;
    })().finally(() => { inFlight = null; });
    return inFlight;
}
