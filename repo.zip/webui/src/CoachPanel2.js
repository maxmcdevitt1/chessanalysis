import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCoach } from './useCoach';
export default function CoachPanel2({ inputs, onJump }) {
    const { notes, busy, err, run } = useCoach();
    return (_jsxs("div", { style: { border: '1px solid #333', borderRadius: 6, padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }, children: [_jsxs("div", { style: { display: 'flex', gap: 8, alignItems: 'center' }, children: [_jsx("button", { onClick: () => run(inputs), disabled: busy, children: busy ? 'Coach…' : 'Generate notes' }), err && _jsx("span", { style: { color: '#c33' }, children: err })] }), _jsx("ul", { style: { margin: 0, paddingLeft: 18, maxHeight: 200, overflow: 'auto' }, children: notes?.map((n, i) => (_jsx("li", { children: n.type === 'move'
                        ? _jsx("a", { onClick: () => onJump(n.moveIndex), role: "button", children: n.text })
                        : _jsx("span", { children: n.text }) }, i))) })] }));
}
