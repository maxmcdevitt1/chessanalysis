import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from 'react';
import { FixedSizeList } from 'react-window';
import { pgnFromMoves, annotatedPgn, analysisJson } from './utils/exporters';
import { useCoach } from './useCoach';
import CoachMoveList from './components/CoachMoveList';
import { acplBandForElo } from './ScoreHelpers';
import { bandById, STRENGTH_BANDS } from './strengthBands';
/* ---------------------------- Tag icon components -------------------------- */
// Inline SVGs you provided, wrapped in a single component.
function TagIcon({ tag, size = 24 }) {
    const s = { width: size, height: size };
    switch (tag) {
        case 'Best':
            return (_jsxs("svg", { viewBox: "0 0 30 30", style: s, xmlns: "http://www.w3.org/2000/svg", "aria-label": "Best move", children: [_jsx("circle", { cx: "15", cy: "15", r: "14", fill: "#34a853" }), _jsx("polygon", { fill: "#ffffff", points: "15,5 18,12 26,12 19.5,17 22,25 15,20 8,25 10.5,17 4,12 12,12" })] }));
        case 'Good':
            return (_jsxs("svg", { viewBox: "0 0 30 30", style: s, xmlns: "http://www.w3.org/2000/svg", "aria-label": "Good move", children: [_jsx("circle", { cx: "15", cy: "15", r: "14", fill: "#4aa3df" }), _jsx("rect", { x: "14", y: "7", width: "2", height: "12", fill: "#ffffff" }), _jsx("circle", { cx: "15", cy: "22", r: "2", fill: "#ffffff" })] }));
        case 'Mistake':
            return (_jsxs("svg", { viewBox: "0 0 30 30", style: s, xmlns: "http://www.w3.org/2000/svg", "aria-label": "Mistake", children: [_jsx("circle", { cx: "15", cy: "15", r: "14", fill: "#f4c430" }), _jsx("path", { d: "M15 8c-2.8 0-5 1.9-5 4h3c0-1 .9-2 2-2s2 1 2 2c0 2-3 2.5-3 5h3c0-2.2 3-3 3-6 0-2.7-2.2-5-5-5z", fill: "#b38300" }), _jsx("circle", { cx: "15", cy: "22", r: "2", fill: "#b38300" })] }));
        case 'Blunder':
            return (_jsxs("svg", { viewBox: "0 0 30 30", style: s, xmlns: "http://www.w3.org/2000/svg", "aria-label": "Blunder", children: [_jsx("rect", { x: "10", y: "6", width: "2", height: "15", fill: "#d93025" }), _jsx("rect", { x: "18", y: "6", width: "2", height: "15", fill: "#d93025" }), _jsx("circle", { cx: "11", cy: "24", r: "2", fill: "#d93025" }), _jsx("circle", { cx: "19", cy: "24", r: "2", fill: "#d93025" })] }));
        case 'Book':
            return (_jsxs("svg", { viewBox: "0 0 30 30", style: s, xmlns: "http://www.w3.org/2000/svg", "aria-label": "Book move", children: [_jsx("rect", { x: "6", y: "5", width: "18", height: "20", rx: "2", ry: "2", fill: "#a56a38" }), _jsx("rect", { x: "6", y: "20", width: "18", height: "4", fill: "#ecd8b5" })] }));
        case 'Genius':
            return _jsx(TagIcon, { tag: "Best", size: size });
        default:
            return _jsx(TagIcon, { tag: "Good", size: size });
    }
}
function Pill({ label, value }) {
    const display = Number.isFinite(value) ? value : '—';
    return (_jsxs("span", { style: {
            padding: '2px 8px',
            borderRadius: 999,
            background: '#1f1f1f',
            border: '1px solid #333',
            fontSize: 16,
            color: '#eaeaea',
        }, children: [label, ": ", _jsx("strong", { children: display })] }));
}
/* --------------------------------- Styles ---------------------------------- */
/** All font sizes are ≥ 18px per your requirement */
const S = {
    // Outer sidebar: fixed height viewport; flex column; content scrolls.
    wrap: {
        height: '100vh',
        padding: 14,
        borderLeft: '1px solid #1f1f1f',
        display: 'flex',
        flexDirection: 'column',
        minWidth: 420,
        fontSize: 18,
        lineHeight: 1.4,
        color: '#ddd',
        boxSizing: 'border-box',
        background: 'linear-gradient(180deg, #151310 0%, #0f0d0b 100%)',
    },
    // Header row (non-scrolling)
    header: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: 8,
        paddingBottom: 8,
        borderBottom: '1px solid #1f1f1f',
    },
    // Scrollable content
    scroll: {
        flex: 1,
        minHeight: 0,
        overflowY: 'auto',
        paddingTop: 8,
        paddingRight: 4,
    },
    // Reusable panel styling
    section: {
        border: '1px solid #2b2b2b',
        borderRadius: 12,
        padding: 14,
        marginTop: 12,
        background: 'linear-gradient(180deg, #1d1a17 0%, #141210 100%)',
        boxShadow: '0 10px 28px rgba(0,0,0,0.28)',
    },
    singleBox: {
        border: '1px solid #2b2b2b',
        borderRadius: 12,
        padding: 16,
        background: 'linear-gradient(180deg, #1d1a17 0%, #141210 100%)',
        boxShadow: '0 10px 28px rgba(0,0,0,0.28)',
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
    },
    subSection: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
    },
    divider: {
        height: 1,
        background: '#2b2b2b',
        margin: '4px 0',
    },
    title: {
        fontWeight: 700,
        marginBottom: 8,
        fontSize: 19,
        letterSpacing: 0.2,
        color: '#f3f0ea',
    },
    small: {
        fontSize: 18,
        opacity: 0.82,
        color: '#c8cbc9',
    },
    button: {
        fontSize: 18,
        padding: '6px 12px',
        borderRadius: 8,
        border: '1px solid #2d2d2d',
        background: '#1f1f1f',
        color: '#eee',
        cursor: 'pointer',
        transition: 'all 120ms ease',
    },
    pill: {
        fontSize: 18,
        padding: '4px 10px',
        borderRadius: 999,
        border: '1px solid #2d2d2d',
        background: '#1c1b18',
        color: '#f0f0f0',
        cursor: 'pointer',
        whiteSpace: 'nowrap',
    },
    input: {
        fontSize: 18,
        background: '#0f0f0f',
        color: '#f3f3f3',
        border: '1px solid #2a2a2a',
        borderRadius: 10,
        padding: '9px 12px',
    },
    select: {
        fontSize: 18,
        background: '#0f0f0f',
        color: '#f3f3f3',
        border: '1px solid #2a2a2a',
        borderRadius: 10,
        padding: '7px 10px',
    },
    table: {
        width: '100%',
        borderCollapse: 'collapse',
        fontSize: 19,
    },
    thtd: {
        borderBottom: '1px solid #2a2a2a',
        padding: '6px 4px',
        textAlign: 'left',
        verticalAlign: 'middle',
    },
    progressOuter: {
        width: '100%',
        height: 10,
        borderRadius: 999,
        background: '#1a1a1a',
        border: '1px solid #2f2f2f',
        overflow: 'hidden',
    },
    progressInner: (pct) => ({
        width: `${Math.max(0, Math.min(100, pct))}%`,
        height: '100%',
        background: 'linear-gradient(90deg, #4caf50, #8bc34a)',
        transition: 'width 180ms ease',
    }),
    progressIndeterminate: {
        width: '45%',
        height: '100%',
        background: 'linear-gradient(90deg, #4caf50, #8bc34a)',
    },
};
/* -------------------------------- Component -------------------------------- */
export default function SidebarPane(props) {
    const { sidebarOpen, setSidebarOpen, openingText, gameEloWhite, gameEloBlack, movesUci = [], moveEvals = [], openingInfo = null, whiteAcc = null, blackAcc = null, avgCplW = null, avgCplB = null, result = '*', showMoves = true, bookUci: _bookUci, onApplyBookMove: _onApplyBookMove, onLoadPgnText, onLoadPgnFile, analyzing, progress, onAnalyze, onAnalyzeFast, onStopAnalyze, review, onRebuildTo, bookDepth = 0, bookMask = [], engineBand, onEngineBandChange, onCoachNotesChange, activeCoachNotes, coachNotes = [], currentPly = 0, onJumpToPly, onGenerateNotes, coachBusy, ply, } = props;
    const ProgressBar = ({ value }) => {
        const pct = typeof value === 'number' && isFinite(value) ? Math.max(0, Math.min(100, value)) : null;
        return (_jsx("div", { style: S.progressOuter, children: pct != null
                ? _jsx("div", { style: S.progressInner(pct) })
                : _jsx("div", { style: S.progressIndeterminate }) }));
    };
    const [selectedGroupId, setSelectedGroupId] = useState(engineBand);
    useEffect(() => {
        setSelectedGroupId(engineBand);
    }, [engineBand]);
    const selectedGroup = bandById(selectedGroupId);
    const deltaEvalForMove = (m) => {
        const side = (m.side === 'White' || m.side === 'W') ? 'W' : 'B';
        const afterWhite = (() => {
            if (typeof m?.cpAfterWhite === 'number')
                return m.cpAfterWhite;
            if (typeof m?.cpAfter === 'number') {
                // cpAfter is stored as opponent POV after the move
                return side === 'W' ? -m.cpAfter : m.cpAfter;
            }
            return null;
        })();
        const beforeWhite = (() => {
            if (typeof m?.cpBefore === 'number')
                return m.cpBefore; // White POV
            if (typeof m?.bestCpBefore === 'number') {
                return side === 'W' ? m.bestCpBefore : -m.bestCpBefore;
            }
            return null;
        })();
        if (afterWhite == null || beforeWhite == null)
            return null;
        return afterWhite - beforeWhite;
    };
    const formatDelta = (cpDelta) => {
        if (cpDelta == null || !isFinite(cpDelta))
            return '—';
        const pawns = cpDelta / 100;
        return `${pawns > 0 ? '+' : ''}${pawns.toFixed(1)}`;
    };
    const moveRowHeight = 46;
    const moveListHeight = Math.min(480, Math.max(moveRowHeight, moveEvals.length * moveRowHeight));
    const moveListColumns = '60px 50px 1fr 1fr 90px 70px 100px';
    const moveListData = useMemo(() => ({
        moveEvals,
        ply,
        bookMask: bookMask || [],
        bookDepth: bookDepth || 0,
        onRebuildTo,
    }), [moveEvals, ply, bookMask, bookDepth, onRebuildTo]);
    const MoveRow = ({ index, style, data }) => {
        const m = data.moveEvals[index];
        if (!m)
            return null;
        const isCurrent = index === data.ply - 1;
        const isOpening = (index < data.bookMask.length ? data.bookMask[index] : index < data.bookDepth);
        const iconTag = isOpening ? 'Book' : (m.tag || '');
        const labelTag = isOpening ? 'Opening' : (m.tag || '');
        return (_jsxs("div", { style: {
                ...style,
                display: 'grid',
                gridTemplateColumns: moveListColumns,
                alignItems: 'center',
                cursor: 'pointer',
                background: isCurrent ? '#1b1b1b' : 'transparent',
                padding: '6px 8px',
                borderBottom: '1px solid #222',
                boxSizing: 'border-box',
            }, onClick: () => data.onRebuildTo(index + 1), children: [_jsx("div", { children: m.moveNo }), _jsx("div", { children: m.side === 'White' ? 'W' : 'B' }), _jsx("div", { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, children: m.san }), _jsx("div", { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, children: m.best || '' }), _jsx("div", { children: formatDelta(deltaEvalForMove(m)) }), _jsx("div", { children: _jsx(TagIcon, { tag: iconTag, size: 20 }) }), _jsx("div", { children: labelTag })] }));
    };
    async function saveFile(defaultPath, ext, content) {
        try {
            if (window.electron?.invoke) {
                await window.electron.invoke('export:save', {
                    defaultPath,
                    filters: ext === 'pgn'
                        ? [{ name: 'PGN', extensions: ['pgn'] }]
                        : [{ name: 'JSON', extensions: ['json'] }],
                    content,
                });
            }
            else {
                const a = document.createElement('a');
                a.href = URL.createObjectURL(new Blob([content], { type: ext === 'pgn' ? 'application/x-chess-pgn' : 'application/json' }));
                a.download = defaultPath;
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(a.href);
            }
        }
        catch (e) {
            console.error('[export] failed', e);
        }
    }
    function exportPGN() {
        const pgn = pgnFromMoves({ movesUci: movesUci || [], result: result || '*' });
        saveFile('game.pgn', 'pgn', pgn);
    }
    function exportAnnotatedPGN() {
        const pgn = annotatedPgn({
            movesUci: movesUci || [],
            moveEvals: moveEvals,
            headers: openingInfo ? { Opening: String(openingInfo) } : undefined,
            result: result || '*',
        });
        saveFile('game_annotated.pgn', 'pgn', pgn);
    }
    function exportJSON() {
        const json = analysisJson({
            movesUci: movesUci || [],
            moveEvals: moveEvals,
            opening: openingInfo || null,
            whiteAcc: whiteAcc ?? null,
            blackAcc: blackAcc ?? null,
            avgCplW: avgCplW ?? null,
            avgCplB: avgCplB ?? null,
            result: result || '*',
        });
        saveFile('game_analysis.json', 'json', json);
    }
    return (_jsxs("aside", { style: S.wrap, children: [_jsxs("div", { style: S.header, children: [_jsx("div", { style: { fontWeight: 700, fontSize: 18 }, children: "Commentary" }), _jsx("button", { style: S.button, onClick: () => setSidebarOpen(!sidebarOpen), title: sidebarOpen ? 'Collapse' : 'Expand', children: sidebarOpen ? '▸' : '▾' })] }), _jsx("div", { style: S.scroll, children: _jsxs("div", { style: S.singleBox, children: [_jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Commentary" }), openingText
                                    ? _jsx("div", { children: openingText })
                                    : _jsx("div", { style: S.small, children: _jsx("em", { children: "Make a move or load a PGN to see commentary." }) })] }), _jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Coach" }), _jsx("div", { style: { display: 'flex', gap: 8 }, children: _jsx("button", { style: { ...S.button, opacity: coachBusy ? 0.6 : 1, pointerEvents: coachBusy ? 'none' : 'auto' }, onClick: () => onGenerateNotes && onGenerateNotes(), title: "Generate per-move coach review", children: coachBusy ? 'Generating…' : 'Generate notes' }) }), coachBusy && (_jsx("div", { style: { marginTop: 8 }, children: _jsx(ProgressBar, {}) })), Array.isArray(coachNotes) && coachNotes.length > 0 ? (_jsx(CoachMoveList, { notes: coachNotes, currentPly: currentPly, onJumpToPly: onJumpToPly || (() => { }), style: { maxHeight: 220 } })) : (_jsx("div", { style: { ...S.small }, children: "No coach notes yet." }))] }), _jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Engine Strength" }), _jsx("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: STRENGTH_BANDS.map((group) => {
                                        const isActive = group.id === selectedGroup.id;
                                        const bandLabel = acplBandForElo(group.centerElo)?.label || group.label;
                                        return (_jsx("button", { style: {
                                                ...S.button,
                                                padding: '10px 14px',
                                                background: isActive ? '#2e7d32' : '#1f1f1f',
                                                borderColor: isActive ? '#2e7d32' : '#333',
                                                color: isActive ? '#fff' : '#ddd',
                                            }, onClick: () => {
                                                setSelectedGroupId(group.id);
                                                onEngineBandChange(group.id);
                                            }, title: group.display || group.label, children: bandLabel }, group.label));
                                    }) }), _jsxs("div", { style: { ...S.small, marginTop: 6 }, children: ["Expected Elo: ", _jsx("strong", { children: `${selectedGroup.range[0]}–${selectedGroup.range[1]}` })] })] }), _jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "PGN" }), _jsx("textarea", { rows: 6, placeholder: "Paste PGN here...", onBlur: (e) => onLoadPgnText(e.target.value), style: { ...S.input, width: '100%', resize: 'vertical' } }), _jsxs("div", { style: { display: 'flex', gap: 10, alignItems: 'center', marginTop: 10, flexWrap: 'wrap' }, children: [_jsx("button", { style: S.button, onClick: onAnalyze, disabled: analyzing, children: "Analyze PGN" }), onAnalyzeFast && (_jsx("button", { style: S.button, onClick: onAnalyzeFast, disabled: analyzing, children: "Fast" })), _jsx("button", { style: S.button, onClick: onStopAnalyze, disabled: !analyzing, children: "Stop" }), _jsxs("label", { style: { marginLeft: 'auto', cursor: 'pointer' }, children: [_jsx("input", { type: "file", accept: ".pgn,.txt", style: { display: 'none' }, onChange: (e) => {
                                                        const f = e.target.files?.[0];
                                                        if (f)
                                                            onLoadPgnFile(f);
                                                    } }), _jsx("span", { style: { textDecoration: 'underline' }, children: "Choose File" })] })] }), analyzing && (_jsxs("div", { style: { marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }, children: [_jsx(ProgressBar, { value: progress ?? 0 }), _jsxs("div", { style: { ...S.small }, children: ["Progress: ", progress ?? 0, "%"] })] }))] }), _jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Game Review" }), _jsxs("div", { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }, children: [_jsxs("div", { children: ["White accuracy:", ' ', _jsx("strong", { children: review?.whiteAcc != null ? `${Math.round(review.whiteAcc)}%` : '—' })] }), _jsxs("div", { children: ["Black accuracy:", ' ', _jsx("strong", { children: review?.blackAcc != null ? `${Math.round(review.blackAcc)}%` : '—' })] }), _jsxs("div", { children: ["Avg CPL (W/B):", ' ', _jsx("strong", { children: review?.avgCplW != null ? Math.round(review.avgCplW) : '—' }), " /", ' ', _jsx("strong", { children: review?.avgCplB != null ? Math.round(review.avgCplB) : '—' })] }), _jsxs("div", { children: ["Rolling ACPL:", ' ', _jsx("strong", { children: review?.rollingAcpl != null
                                                        ? `${Math.round(review.rollingAcpl)} (${review?.rollingAcc != null ? Math.round(review.rollingAcc) : '—'}% acc)`
                                                        : '—' }), ' ', review?.rollingSamples ? `(last ${review.rollingSamples} plies)` : ''] })] }), _jsxs("div", { style: {
                                        display: 'grid',
                                        gridTemplateColumns: '1fr 1fr',
                                        gap: 10,
                                        padding: '8px 10px',
                                        background: '#0f0f0f',
                                        border: '1px solid #222',
                                        borderRadius: 8,
                                    }, children: [_jsxs("div", { children: [_jsx("div", { style: S.small, children: "White moves" }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }, children: [_jsx(Pill, { label: "Best", value: review?.quality?.W?.best }), _jsx(Pill, { label: "Good", value: review?.quality?.W?.good }), _jsx(Pill, { label: "Inacc", value: review?.quality?.W?.inaccuracy ?? review?.quality?.W?.inacc }), _jsx(Pill, { label: "Mist", value: review?.quality?.W?.mistake }), _jsx(Pill, { label: "Blun", value: review?.quality?.W?.blunder })] })] }), _jsxs("div", { children: [_jsx("div", { style: S.small, children: "Black moves" }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }, children: [_jsx(Pill, { label: "Best", value: review?.quality?.B?.best }), _jsx(Pill, { label: "Good", value: review?.quality?.B?.good }), _jsx(Pill, { label: "Inacc", value: review?.quality?.B?.inaccuracy ?? review?.quality?.B?.inacc }), _jsx(Pill, { label: "Mist", value: review?.quality?.B?.mistake }), _jsx(Pill, { label: "Blun", value: review?.quality?.B?.blunder })] })] })] })] }), _jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Export" }), _jsxs("div", { style: { display: 'flex', flexWrap: 'wrap', gap: 8 }, children: [_jsx("button", { style: S.button, onClick: exportPGN, children: "Export PGN" }), _jsx("button", { style: S.button, onClick: exportAnnotatedPGN, children: "PGN (annotated)" }), _jsx("button", { style: S.button, onClick: exportJSON, children: "Export JSON" })] })] }), showMoves && (_jsxs(_Fragment, { children: [_jsx("div", { style: S.divider }), _jsxs("div", { style: S.subSection, children: [_jsx("div", { style: S.title, children: "Moves" }), _jsxs("div", { style: { maxHeight: 480, overflow: 'hidden', border: '1px solid #222', borderRadius: 8 }, children: [_jsxs("div", { style: {
                                                        display: 'grid',
                                                        gridTemplateColumns: moveListColumns,
                                                        position: 'sticky',
                                                        top: 0,
                                                        background: '#111',
                                                        padding: '8px',
                                                        fontWeight: 600,
                                                        fontSize: 14,
                                                        zIndex: 1,
                                                        borderBottom: '1px solid #222',
                                                    }, children: [_jsx("div", { children: "#" }), _jsx("div", { children: "Side" }), _jsx("div", { children: "SAN" }), _jsx("div", { children: "Best" }), _jsx("div", { children: "Eval" }), _jsx("div", { children: "Icon" }), _jsx("div", { children: "Tag" })] }), _jsx(FixedSizeList, { height: moveListHeight, itemCount: moveEvals.length, itemData: moveListData, itemSize: moveRowHeight, width: "100%", itemKey: (idx) => moveEvals[idx]?.uci ? `${idx}-${moveEvals[idx].uci}` : idx, children: MoveRow })] })] })] }))] }) })] }));
}
/* --------------------------- CoachSection (local) --------------------------- */
function CoachSection({ openingText, review, moveEvals, onRebuildTo, onNotes, activeNotes }) {
    const { notes, busy, err, run } = useCoach();
    const inputs = useMemo(() => ({
        summary: {
            opening: openingText || undefined,
            whiteAcc: review?.whiteAcc ?? undefined,
            blackAcc: review?.blackAcc ?? undefined,
            avgCplW: review?.avgCplW ?? undefined,
            avgCplB: review?.avgCplB ?? undefined,
        },
        moments: moveEvals
            .filter(m => m.tag === 'Mistake' || m.tag === 'Blunder' || m.tag === 'Best' || m.tag === 'Genius')
            .map(m => ({
            index: m.index,
            moveNo: m.moveNo,
            side: m.side === 'White' ? 'W' : 'B',
            san: m.san,
            tag: m.tag === 'Genius' ? 'Best' : (m.tag || 'Good'),
            cpBefore: m.cpBefore ?? null,
            cpAfter: m.cpAfter ?? null,
            best: m.best ?? null,
        })),
        pgn: undefined
    }), [openingText, review, moveEvals]);
    useEffect(() => {
        onNotes?.(notes || null);
    }, [notes, onNotes]);
    const activeKey = (n) => `${n?.type}:${n?.type === 'move' ? n.moveIndex : ''}:${n?.text || ''}`;
    const activeSet = new Set((activeNotes || []).map(activeKey));
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 8 }, children: [_jsxs("div", { style: { display: 'flex', gap: 8, alignItems: 'center' }, children: [_jsx("button", { style: S.button, onClick: () => run(inputs), disabled: busy, children: busy ? 'Coach…' : 'Generate notes' }), err && _jsx("span", { style: S.small, children: "Coach offline" })] }), (activeNotes?.length ?? 0) > 0 && (_jsx("div", { style: { ...S.small, padding: '4px 8px', border: '1px dashed #444', borderRadius: 6 }, children: activeNotes?.map((n, i) => (_jsx("div", { children: n.type === 'move' ? (_jsxs(_Fragment, { children: [_jsxs("strong", { children: ["Move ", ((n.moveIndex ?? 0) + 1), ":"] }), " ", n.text] })) : (n.text) }, i))) })), _jsx("ul", { style: { margin: 0, paddingLeft: 18, maxHeight: 200, overflow: 'auto' }, children: notes?.map((n, i) => (_jsx("li", { style: activeSet.has(activeKey(n))
                        ? { background: '#1f1f1f', borderRadius: 6, padding: '2px 6px' }
                        : undefined, children: n.type === 'move'
                        ? _jsx("a", { onClick: () => onRebuildTo((n.moveIndex ?? 0) + 1), role: "button", children: n.text })
                        : _jsx("span", { children: n.text }) }, i))) || null })] }));
}
