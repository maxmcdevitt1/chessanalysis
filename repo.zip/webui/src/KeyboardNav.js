import { useGlobalArrowNav } from './hooks/useGlobalArrowNav';
export default function KeyboardNav({ ply, movesUciLength, onRebuildTo, enabled = true }) {
    useGlobalArrowNav({ ply, total: movesUciLength, onRebuildTo, enabled });
    return null;
}
